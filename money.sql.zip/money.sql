-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : lun. 13 mars 2023 à 18:29
-- Version du serveur : 10.4.19-MariaDB
-- Version de PHP : 8.0.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `ccgim`
--

-- --------------------------------------------------------

--
-- Structure de la table `money`
--

CREATE TABLE `money` (
  `id_money` int(111) NOT NULL,
  `date_money` datetime DEFAULT NULL,
  `reseau` int(11) DEFAULT NULL,
  `libelle` varchar(225) DEFAULT NULL,
  `type_transac` int(11) DEFAULT 0,
  `debit_transac` float NOT NULL DEFAULT 0,
  `credit_transac` float NOT NULL DEFAULT 0,
  `user_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `money`
--

INSERT INTO `money` (`id_money`, `date_money`, `reseau`, `libelle`, `type_transac`, `debit_transac`, `credit_transac`, `user_id`) VALUES
(1, '2023-03-11 13:10:39', 1, 'Entree', 1, 30000, 0, 1),
(2, '2023-03-11 14:10:39', 1, 'Sortie', 2, 0, 15000, 1),
(3, '2023-03-13 11:31:00', 1, 'tester', 1, 500, 0, 1),
(4, '2023-03-13 11:53:00', 1, 'Entr&eacute; auth', 2, 0, 15000, 1),
(5, '2023-03-13 14:20:00', 1, 'tester', 1, 500, 0, 1),
(6, '2023-03-13 14:21:00', 1, 'tester', 2, 0, 500, 1),
(7, '2023-03-13 14:30:00', 1, 'tester', 2, 0, 500, 1),
(8, '2023-03-13 14:57:00', 1, 'd&eacute;pot', 1, 50000, 0, 1),
(9, '2023-03-13 14:58:00', 1, 'Retrait', 2, 0, 250, 1),
(10, '2023-03-13 14:58:00', 1, 'tester', 2, 0, 250, 1),
(11, '2023-03-13 14:58:00', 1, 'tester', 2, 0, 250, 1),
(12, '2023-03-13 15:24:00', 1, 'Entr&eacute;', 1, 75000, 0, 1),
(13, '2023-03-13 15:25:00', 2, 'Entr&eacute;', 1, 75000, 0, 1),
(14, '2023-03-13 15:26:00', 2, 'Retrait', 2, 0, 25000, 1),
(15, '2023-03-13 15:31:00', 2, 'D&eacute;pot', 1, 250000, 0, 1),
(16, '2023-03-13 15:32:00', 3, 'D&eacute;pot', 1, 250000, 0, 1),
(17, '2023-03-13 15:33:00', 3, 'Retrait', 2, 0, 15000, 1),
(18, '2023-03-13 15:35:00', 3, 'Retrait', 2, 0, 5000, 1),
(19, '2023-03-13 15:46:00', 4, 'Entr&eacute;', 1, 500000, 0, 1),
(20, '2023-03-13 15:46:00', 4, 'Retrait', 2, 0, 17000, 1);

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `money`
--
ALTER TABLE `money`
  ADD PRIMARY KEY (`id_money`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `money`
--
ALTER TABLE `money`
  MODIFY `id_money` int(111) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
